# Toonmania2 0.5.2

A Kodi video add-on for streaming cartoons and anime from [animetoon](http://www.animetoon.org/) and [animeplus](http://www.animeplus.tv/).  
Install it from [this zip here](https://github.com/doko-desuka/plugin.video.toonmania2/raw/master/plugin.video.toonmania2-0.5.2.zip) or install it from [my repository](https://github.com/doko-desuka/doko.repository/releases) to get automatic updates.

Pull-requests are always welcome.

![screenshot](https://images2.imgbox.com/07/d5/IZj0NnOl_o.png)
